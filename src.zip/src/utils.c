#include "utils.h"

#include <math.h>
#define M_PI 3.14159265358979323846

double degree_to_radian(double degree){
	return degree * M_PI / 180.0;
}

