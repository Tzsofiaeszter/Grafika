#ifndef OBJ_DRAW_H
#define OBJ_DRAW_H

#include "model.h"

void draw_model(const Model* model);
void draw_triangles(const Model* model);

#endif 
