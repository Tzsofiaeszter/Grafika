#ifndef OBJ_TRANSFORM_H
#define OBJ_TRANSFORM_H

#include "model.h"

void scale_model(Model* model, double sx, double sy, double sz);

#endif
