#ifndef OBJ_INFO_H
#define OBJ_INFO_H

#include "model.h"

void print_model_info(const Model* model);
void print_bounding_box(const Model* model);

#endif 

